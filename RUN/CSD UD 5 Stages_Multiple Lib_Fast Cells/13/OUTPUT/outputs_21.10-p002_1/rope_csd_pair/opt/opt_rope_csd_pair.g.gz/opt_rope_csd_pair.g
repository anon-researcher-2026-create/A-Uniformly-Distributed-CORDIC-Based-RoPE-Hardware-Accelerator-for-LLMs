######################################################################

# Created by Genus(TM) Synthesis Solution 21.10-p002_1 on Wed Apr 22 18:38:38 IST 2026

# This file contains the Genus script for design:rope_csd_pair

######################################################################

set_db -quiet information_level 9
set_db -quiet init_lib_search_path {/home/redhatacademy19/Documents/Siddhant/gsclib045_all_v4.8/gsclib045/timing /home/redhatacademy19/Documents/Siddhant/gsclib045_all_v4.8/gsclib045_hvt/timing /home/redhatacademy19/Documents/Siddhant/gsclib045_all_v4.8/gsclib045_lvt/timing { }}
set_db -quiet design_mode_process 60.0
set_db -quiet phys_assume_met_fill 0.0
set_db -quiet map_placed_for_route_early_global false
set_db -quiet phys_use_invs_extraction true
set_db -quiet phys_route_time_out 120.0
set_db -quiet db_units 2000
set_db -quiet capacitance_per_unit_length_mmmc {}
set_db -quiet resistance_per_unit_length_mmmc {}
set_db -quiet runtime_by_stage {{PBS_Generic-Start 0 52 0.0 7.0} {to_generic 15 67 15 22} {first_condense 3 71 3 27} {PBS_Generic_Opt-Post 19 71 19.007237 26.007237} {{PBS_Generic-Postgen HBO Optimizations} 0 71 0.0 26.007237} {PBS_TechMap-Start 0 72 0.0 27.00641} {{PBS_TechMap-Premap HBO Optimizations} 0 72 0.0 27.00641} {second_condense 2 74 2 30} {reify 6 80 9 40} {global_incr_map 1 81 0 40} {{PBS_Techmap-Global Mapping} 9 81 9.179373000000002 36.185783} {{PBS_TechMap-Datapath Postmap Operations} 0 81 -0.005168000000004724 36.180614999999996} {{PBS_TechMap-Postmap HBO Optimizations} 0 81 -0.006437999999995725 36.174177} {{PBS_TechMap-Postmap Clock Gating} 0 81 0.0 36.174177} {{PBS_TechMap-Postmap Cleanup} 1 82 0.9938499999999948 37.168026999999995} {PBS_Techmap-Post_MBCI 0 82 0.0 37.168026999999995} {incr_opt 2 84 1 43} }
set_db -quiet timing_adjust_tns_of_complex_flops false
set_db -quiet tinfo_tstamp_file .rs_redhatacademy19.tstamp
set_db -quiet metric_enable true
set_db -quiet script_search_path { $scriptDir }
set_db -quiet use_area_from_lef true
set_db -quiet flow_metrics_snapshot_uuid c1c498df-ffbf-4699-99e8-1a064b9e6b9f
set_db -quiet phys_use_segment_parasitics true
set_db -quiet probabilistic_extraction true
set_db -quiet ple_correlation_factors {1.9000 2.0000}
set_db -quiet maximum_interval_of_vias inf
set_db -quiet layer_aware_buffer true
set_db -quiet ple_mode global
set_db -quiet wireload_selection none
set_db -quiet operating_condition:default_emulate_libset_max/fast_vdd1v2/PVT_1P32V_0C .tree_type balanced_tree
set_db -quiet operating_condition:default_emulate_libset_max/fast_vdd1v2/_nominal_ .tree_type balanced_tree
set_db -quiet operating_condition:default_emulate_libset_max/fast_vdd1v2/PVT_1P32V_0C .tree_type balanced_tree
set_db -quiet operating_condition:default_emulate_libset_max/fast_vdd1v2/_nominal_ .tree_type balanced_tree
# BEGIN MSV SECTION
# END MSV SECTION
define_clock -name clk -domain domain_1 -period 2000.0 -divide_period 1 -rise 0 -divide_rise 1 -fall 1 -divide_fall 2 -remove -design design:rope_csd_pair port:rope_csd_pair/clk
define_cost_group -design design:rope_csd_pair -name clk
external_delay -accumulate -input {0.0 no_value 0.0 no_value} -clock clock:rope_csd_pair/clk -name create_clock_delay_domain_1_clk_R_0 port:rope_csd_pair/clk
set_db -quiet external_delay:rope_csd_pair/create_clock_delay_domain_1_clk_R_0 .clock_network_latency_included true
external_delay -accumulate -input {no_value 0.0 no_value 0.0} -clock clock:rope_csd_pair/clk -edge_fall -name create_clock_delay_domain_1_clk_F_0 port:rope_csd_pair/clk
set_db -quiet external_delay:rope_csd_pair/create_clock_delay_domain_1_clk_F_0 .clock_network_latency_included true
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2 port:rope_csd_pair/rst
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_1_1 {{port:rope_csd_pair/x_in[14]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_2_1 {{port:rope_csd_pair/x_in[13]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_3_1 {{port:rope_csd_pair/x_in[12]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_4_1 {{port:rope_csd_pair/x_in[11]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_5_1 {{port:rope_csd_pair/x_in[10]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_6_1 {{port:rope_csd_pair/x_in[9]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_7_1 {{port:rope_csd_pair/x_in[8]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_8_1 {{port:rope_csd_pair/x_in[7]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_9_1 {{port:rope_csd_pair/x_in[6]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_10_1 {{port:rope_csd_pair/x_in[5]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_11_1 {{port:rope_csd_pair/x_in[4]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_12_1 {{port:rope_csd_pair/x_in[3]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_13_1 {{port:rope_csd_pair/x_in[2]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_14_1 {{port:rope_csd_pair/x_in[1]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_15_1 {{port:rope_csd_pair/x_in[0]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_16_1 {{port:rope_csd_pair/y_in[14]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_17_1 {{port:rope_csd_pair/y_in[13]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_18_1 {{port:rope_csd_pair/y_in[12]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_19_1 {{port:rope_csd_pair/y_in[11]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_20_1 {{port:rope_csd_pair/y_in[10]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_21_1 {{port:rope_csd_pair/y_in[9]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_22_1 {{port:rope_csd_pair/y_in[8]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_23_1 {{port:rope_csd_pair/y_in[7]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_24_1 {{port:rope_csd_pair/y_in[6]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_25_1 {{port:rope_csd_pair/y_in[5]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_26_1 {{port:rope_csd_pair/y_in[4]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_27_1 {{port:rope_csd_pair/y_in[3]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_28_1 {{port:rope_csd_pair/y_in[2]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_29_1 {{port:rope_csd_pair/y_in[1]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_30_1 {{port:rope_csd_pair/y_in[0]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_31_1 {{port:rope_csd_pair/angle_bits[9]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_32_1 {{port:rope_csd_pair/angle_bits[8]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_33_1 {{port:rope_csd_pair/angle_bits[7]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_34_1 {{port:rope_csd_pair/angle_bits[6]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_35_1 {{port:rope_csd_pair/angle_bits[5]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_36_1 {{port:rope_csd_pair/angle_bits[4]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_37_1 {{port:rope_csd_pair/angle_bits[3]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_38_1 {{port:rope_csd_pair/angle_bits[2]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_39_1 {{port:rope_csd_pair/angle_bits[1]}}
external_delay -accumulate -input {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_2_40_1 {{port:rope_csd_pair/angle_bits[0]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_3 {{port:rope_csd_pair/x_out[14]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_3_40_1 {{port:rope_csd_pair/x_out[13]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_3_41_1 {{port:rope_csd_pair/x_out[12]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_3_42_1 {{port:rope_csd_pair/x_out[11]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_3_43_1 {{port:rope_csd_pair/x_out[10]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_3_44_1 {{port:rope_csd_pair/x_out[9]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_3_45_1 {{port:rope_csd_pair/x_out[8]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_3_46_1 {{port:rope_csd_pair/x_out[7]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_3_47_1 {{port:rope_csd_pair/x_out[6]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_3_48_1 {{port:rope_csd_pair/x_out[5]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_3_49_1 {{port:rope_csd_pair/x_out[4]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_3_50_1 {{port:rope_csd_pair/x_out[3]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_3_51_1 {{port:rope_csd_pair/x_out[2]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_3_52_1 {{port:rope_csd_pair/x_out[1]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_3_53_1 {{port:rope_csd_pair/x_out[0]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_3_54_1 {{port:rope_csd_pair/y_out[14]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_3_55_1 {{port:rope_csd_pair/y_out[13]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_3_56_1 {{port:rope_csd_pair/y_out[12]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_3_57_1 {{port:rope_csd_pair/y_out[11]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_3_58_1 {{port:rope_csd_pair/y_out[10]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_3_59_1 {{port:rope_csd_pair/y_out[9]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_3_60_1 {{port:rope_csd_pair/y_out[8]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_3_61_1 {{port:rope_csd_pair/y_out[7]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_3_62_1 {{port:rope_csd_pair/y_out[6]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_3_63_1 {{port:rope_csd_pair/y_out[5]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_3_64_1 {{port:rope_csd_pair/y_out[4]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_3_65_1 {{port:rope_csd_pair/y_out[3]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_3_66_1 {{port:rope_csd_pair/y_out[2]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_3_67_1 {{port:rope_csd_pair/y_out[1]}}
external_delay -accumulate -output {200.0 200.0 200.0 200.0} -clock clock:rope_csd_pair/clk -name rope.sdc_line_3_68_1 {{port:rope_csd_pair/y_out[0]}}
path_group -paths [specify_paths -to clock:rope_csd_pair/clk]  -name clk -group cost_group:rope_csd_pair/clk -user_priority -1047552
# BEGIN DFT SECTION
set_db -quiet dft_scan_style muxed_scan
set_db -quiet dft_scanbit_waveform_analysis false
# END DFT SECTION
set_db -quiet design:rope_csd_pair .seq_reason_deleted_internal {{{core/delta_pipe[4][3]} unloaded {core/delta_pipe[4][3]}} {{core/delta_pipe[4][2]} unloaded {core/delta_pipe[4][2]}} {{core/delta_pipe[4][1]} unloaded {core/delta_pipe[4][1]}} {{core/delta_pipe[4][0]} unloaded {core/delta_pipe[4][0]}} {{core/delta_pipe[3][2]} unloaded {core/delta_pipe[3][2]}} {{core/delta_pipe[3][1]} unloaded {core/delta_pipe[3][1]}} {{core/delta_pipe[3][0]} unloaded {core/delta_pipe[3][0]}} {{core/delta_pipe[2][1]} unloaded {core/delta_pipe[2][1]}} {{core/delta_pipe[2][0]} unloaded {core/delta_pipe[2][0]}} {{core/delta_pipe[1][0]} unloaded {core/delta_pipe[1][0]}} {{core_delta_pipe_reg[0][0][2]} {{merged with core_delta_pipe_reg[0][0][1]}} {core/delta_pipe[0][0][2]} {core/delta_pipe[0][0][1]}}}
set_db -quiet design:rope_csd_pair .qos_by_stage {{to_generic {wns -11111111} {tns -111111111} {vep -111111111} {area 14539} {cell_count 4656} {utilization  0.00} {runtime 15 67 15 22} }{first_condense {wns -11111111} {tns -111111111} {vep -111111111} {area 10346} {cell_count 3396} {utilization  0.00} {runtime 3 71 3 27} }{second_condense {wns -11111111} {tns -111111111} {vep -111111111} {area 10280} {cell_count 3371} {utilization  0.00} {runtime 2 74 2 30} }{reify {wns 1102} {tns 0} {vep 0} {area 3882} {cell_count 1510} {utilization  0.00} {runtime 6 80 9 40} }{global_incr_map {wns 1106} {tns 0} {vep 0} {area 3793} {cell_count 1506} {utilization  0.00} {runtime 1 81 0 40} }{incr_opt {wns 214748365} {tns 0} {vep 0} {area 3766} {cell_count 1473} {utilization  0.00} {runtime 2 84 1 43} }}
set_db -quiet design:rope_csd_pair .seq_mbci_coverage 0.0
set_db -quiet design:rope_csd_pair .hdl_user_name rope_csd_pair
set_db -quiet design:rope_csd_pair .hdl_filelist {{default -v2001 {SYNTHESIS} {/home/redhatacademy19/Documents/Siddhant/RTL/csd_ud_stage.v /home/redhatacademy19/Documents/Siddhant/RTL/csd_ud_cordic_core.v /home/redhatacademy19/Documents/Siddhant/RTL/rope_csd_pair.v /home/redhatacademy19/Documents/Siddhant/RTL/csd_control.v} {$rtlDir} {}}}
set_db -quiet design:rope_csd_pair .seq_reason_deleted {{{core/delta_pipe[4][3]} unloaded} {{core/delta_pipe[4][2]} unloaded} {{core/delta_pipe[4][1]} unloaded} {{core/delta_pipe[4][0]} unloaded} {{core/delta_pipe[3][2]} unloaded} {{core/delta_pipe[3][1]} unloaded} {{core/delta_pipe[3][0]} unloaded} {{core/delta_pipe[2][1]} unloaded} {{core/delta_pipe[2][0]} unloaded} {{core/delta_pipe[1][0]} unloaded} {{core_delta_pipe_reg[0][0][2]} {{merged with core_delta_pipe_reg[0][0][1]}}}}
set_db -quiet design:rope_csd_pair .verification_directory fv/rope_csd_pair
set_db -quiet design:rope_csd_pair .lp_clock_gating_max_flops inf
set_db -quiet design:rope_csd_pair .arch_filename /home/redhatacademy19/Documents/Siddhant/RTL/rope_csd_pair.v
set_db -quiet design:rope_csd_pair .entity_filename /home/redhatacademy19/Documents/Siddhant/RTL/rope_csd_pair.v
set_db -quiet port:rope_csd_pair/clk .original_name clk
set_db -quiet port:rope_csd_pair/rst .original_name rst
set_db -quiet {port:rope_csd_pair/x_in[14]} .original_name {x_in[14]}
set_db -quiet {port:rope_csd_pair/x_in[13]} .original_name {x_in[13]}
set_db -quiet {port:rope_csd_pair/x_in[12]} .original_name {x_in[12]}
set_db -quiet {port:rope_csd_pair/x_in[11]} .original_name {x_in[11]}
set_db -quiet {port:rope_csd_pair/x_in[10]} .original_name {x_in[10]}
set_db -quiet {port:rope_csd_pair/x_in[9]} .original_name {x_in[9]}
set_db -quiet {port:rope_csd_pair/x_in[8]} .original_name {x_in[8]}
set_db -quiet {port:rope_csd_pair/x_in[7]} .original_name {x_in[7]}
set_db -quiet {port:rope_csd_pair/x_in[6]} .original_name {x_in[6]}
set_db -quiet {port:rope_csd_pair/x_in[5]} .original_name {x_in[5]}
set_db -quiet {port:rope_csd_pair/x_in[4]} .original_name {x_in[4]}
set_db -quiet {port:rope_csd_pair/x_in[3]} .original_name {x_in[3]}
set_db -quiet {port:rope_csd_pair/x_in[2]} .original_name {x_in[2]}
set_db -quiet {port:rope_csd_pair/x_in[1]} .original_name {x_in[1]}
set_db -quiet {port:rope_csd_pair/x_in[0]} .original_name {x_in[0]}
set_db -quiet {port:rope_csd_pair/y_in[14]} .original_name {y_in[14]}
set_db -quiet {port:rope_csd_pair/y_in[13]} .original_name {y_in[13]}
set_db -quiet {port:rope_csd_pair/y_in[12]} .original_name {y_in[12]}
set_db -quiet {port:rope_csd_pair/y_in[11]} .original_name {y_in[11]}
set_db -quiet {port:rope_csd_pair/y_in[10]} .original_name {y_in[10]}
set_db -quiet {port:rope_csd_pair/y_in[9]} .original_name {y_in[9]}
set_db -quiet {port:rope_csd_pair/y_in[8]} .original_name {y_in[8]}
set_db -quiet {port:rope_csd_pair/y_in[7]} .original_name {y_in[7]}
set_db -quiet {port:rope_csd_pair/y_in[6]} .original_name {y_in[6]}
set_db -quiet {port:rope_csd_pair/y_in[5]} .original_name {y_in[5]}
set_db -quiet {port:rope_csd_pair/y_in[4]} .original_name {y_in[4]}
set_db -quiet {port:rope_csd_pair/y_in[3]} .original_name {y_in[3]}
set_db -quiet {port:rope_csd_pair/y_in[2]} .original_name {y_in[2]}
set_db -quiet {port:rope_csd_pair/y_in[1]} .original_name {y_in[1]}
set_db -quiet {port:rope_csd_pair/y_in[0]} .original_name {y_in[0]}
set_db -quiet {port:rope_csd_pair/angle_bits[9]} .original_name {angle_bits[9]}
set_db -quiet {port:rope_csd_pair/angle_bits[8]} .original_name {angle_bits[8]}
set_db -quiet {port:rope_csd_pair/angle_bits[7]} .original_name {angle_bits[7]}
set_db -quiet {port:rope_csd_pair/angle_bits[6]} .original_name {angle_bits[6]}
set_db -quiet {port:rope_csd_pair/angle_bits[5]} .original_name {angle_bits[5]}
set_db -quiet {port:rope_csd_pair/angle_bits[4]} .original_name {angle_bits[4]}
set_db -quiet {port:rope_csd_pair/angle_bits[3]} .original_name {angle_bits[3]}
set_db -quiet {port:rope_csd_pair/angle_bits[2]} .original_name {angle_bits[2]}
set_db -quiet {port:rope_csd_pair/angle_bits[1]} .original_name {angle_bits[1]}
set_db -quiet {port:rope_csd_pair/angle_bits[0]} .original_name {angle_bits[0]}
set_db -quiet {port:rope_csd_pair/x_out[14]} .original_name {x_out[14]}
set_db -quiet {port:rope_csd_pair/x_out[13]} .original_name {x_out[13]}
set_db -quiet {port:rope_csd_pair/x_out[12]} .original_name {x_out[12]}
set_db -quiet {port:rope_csd_pair/x_out[11]} .original_name {x_out[11]}
set_db -quiet {port:rope_csd_pair/x_out[10]} .original_name {x_out[10]}
set_db -quiet {port:rope_csd_pair/x_out[9]} .original_name {x_out[9]}
set_db -quiet {port:rope_csd_pair/x_out[8]} .original_name {x_out[8]}
set_db -quiet {port:rope_csd_pair/x_out[7]} .original_name {x_out[7]}
set_db -quiet {port:rope_csd_pair/x_out[6]} .original_name {x_out[6]}
set_db -quiet {port:rope_csd_pair/x_out[5]} .original_name {x_out[5]}
set_db -quiet {port:rope_csd_pair/x_out[4]} .original_name {x_out[4]}
set_db -quiet {port:rope_csd_pair/x_out[3]} .original_name {x_out[3]}
set_db -quiet {port:rope_csd_pair/x_out[2]} .original_name {x_out[2]}
set_db -quiet {port:rope_csd_pair/x_out[1]} .original_name {x_out[1]}
set_db -quiet {port:rope_csd_pair/x_out[0]} .original_name {x_out[0]}
set_db -quiet {port:rope_csd_pair/y_out[14]} .original_name {y_out[14]}
set_db -quiet {port:rope_csd_pair/y_out[13]} .original_name {y_out[13]}
set_db -quiet {port:rope_csd_pair/y_out[12]} .original_name {y_out[12]}
set_db -quiet {port:rope_csd_pair/y_out[11]} .original_name {y_out[11]}
set_db -quiet {port:rope_csd_pair/y_out[10]} .original_name {y_out[10]}
set_db -quiet {port:rope_csd_pair/y_out[9]} .original_name {y_out[9]}
set_db -quiet {port:rope_csd_pair/y_out[8]} .original_name {y_out[8]}
set_db -quiet {port:rope_csd_pair/y_out[7]} .original_name {y_out[7]}
set_db -quiet {port:rope_csd_pair/y_out[6]} .original_name {y_out[6]}
set_db -quiet {port:rope_csd_pair/y_out[5]} .original_name {y_out[5]}
set_db -quiet {port:rope_csd_pair/y_out[4]} .original_name {y_out[4]}
set_db -quiet {port:rope_csd_pair/y_out[3]} .original_name {y_out[3]}
set_db -quiet {port:rope_csd_pair/y_out[2]} .original_name {y_out[2]}
set_db -quiet {port:rope_csd_pair/y_out[1]} .original_name {y_out[1]}
set_db -quiet {port:rope_csd_pair/y_out[0]} .original_name {y_out[0]}
set_db -quiet module:rope_csd_pair/csd_ud_stage_WIDTH15_SHIFT12_SHIFT23 .hdl_user_name csd_ud_stage
set_db -quiet module:rope_csd_pair/csd_ud_stage_WIDTH15_SHIFT12_SHIFT23 .hdl_filelist {{default -v2001 {SYNTHESIS} {/home/redhatacademy19/Documents/Siddhant/RTL/csd_ud_stage.v} {$rtlDir} {}}}
set_db -quiet module:rope_csd_pair/csd_ud_stage_WIDTH15_SHIFT12_SHIFT23 .lp_clock_gating_max_flops inf
set_db -quiet module:rope_csd_pair/csd_ud_stage_WIDTH15_SHIFT12_SHIFT23 .arch_filename /home/redhatacademy19/Documents/Siddhant/RTL/csd_ud_stage.v
set_db -quiet module:rope_csd_pair/csd_ud_stage_WIDTH15_SHIFT12_SHIFT23 .entity_filename /home/redhatacademy19/Documents/Siddhant/RTL/csd_ud_stage.v
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[5]} .original_name {{core/STAGE[1].stage_i/y_out[5]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[5]} .single_bit_orig_name {core/STAGE[1].stage_i/y_out[5]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[5]/Q} .original_name {core/STAGE[1].stage_i/y_out[5]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[13]} .original_name {{core/STAGE[1].stage_i/y_out[13]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[13]} .single_bit_orig_name {core/STAGE[1].stage_i/y_out[13]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[13]/Q} .original_name {core/STAGE[1].stage_i/y_out[13]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[11]} .original_name {{core/STAGE[1].stage_i/y_out[11]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[11]} .single_bit_orig_name {core/STAGE[1].stage_i/y_out[11]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[11]/Q} .original_name {core/STAGE[1].stage_i/y_out[11]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[7]} .original_name {{core/STAGE[1].stage_i/y_out[7]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[7]} .single_bit_orig_name {core/STAGE[1].stage_i/y_out[7]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[7]/Q} .original_name {core/STAGE[1].stage_i/y_out[7]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[6]} .original_name {{core/STAGE[1].stage_i/y_out[6]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[6]} .single_bit_orig_name {core/STAGE[1].stage_i/y_out[6]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[6]/Q} .original_name {core/STAGE[1].stage_i/y_out[6]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[10]} .original_name {{core/STAGE[1].stage_i/y_out[10]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[10]} .single_bit_orig_name {core/STAGE[1].stage_i/y_out[10]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[10]/Q} .original_name {core/STAGE[1].stage_i/y_out[10]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[14]} .original_name {{core/STAGE[1].stage_i/y_out[14]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[14]} .single_bit_orig_name {core/STAGE[1].stage_i/y_out[14]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[14]/Q} .original_name {core/STAGE[1].stage_i/y_out[14]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[2]} .original_name {{core/STAGE[1].stage_i/y_out[2]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[2]} .single_bit_orig_name {core/STAGE[1].stage_i/y_out[2]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[2]/Q} .original_name {core/STAGE[1].stage_i/y_out[2]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[12]} .original_name {{core/STAGE[1].stage_i/y_out[12]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[12]} .single_bit_orig_name {core/STAGE[1].stage_i/y_out[12]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[12]/Q} .original_name {core/STAGE[1].stage_i/y_out[12]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[9]} .original_name {{core/STAGE[1].stage_i/y_out[9]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[9]} .single_bit_orig_name {core/STAGE[1].stage_i/y_out[9]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[9]/Q} .original_name {core/STAGE[1].stage_i/y_out[9]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[3]} .original_name {{core/STAGE[1].stage_i/y_out[3]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[3]} .single_bit_orig_name {core/STAGE[1].stage_i/y_out[3]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[3]/Q} .original_name {core/STAGE[1].stage_i/y_out[3]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[4]} .original_name {{core/STAGE[1].stage_i/y_out[4]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[4]} .single_bit_orig_name {core/STAGE[1].stage_i/y_out[4]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[4]/Q} .original_name {core/STAGE[1].stage_i/y_out[4]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[8]} .original_name {{core/STAGE[1].stage_i/y_out[8]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[8]} .single_bit_orig_name {core/STAGE[1].stage_i/y_out[8]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[8]/Q} .original_name {core/STAGE[1].stage_i/y_out[8]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[1]} .original_name {{core/STAGE[1].stage_i/y_out[1]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[1]} .single_bit_orig_name {core/STAGE[1].stage_i/y_out[1]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[1]/Q} .original_name {core/STAGE[1].stage_i/y_out[1]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[0]} .original_name {{core/STAGE[1].stage_i/y_out[0]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[0]} .single_bit_orig_name {core/STAGE[1].stage_i/y_out[0]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[1].stage_i/y_out_reg[0]/Q} .original_name {core/STAGE[1].stage_i/y_out[0]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[5]} .original_name {{core/STAGE[1].stage_i/x_out[5]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[5]} .single_bit_orig_name {core/STAGE[1].stage_i/x_out[5]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[5]/Q} .original_name {core/STAGE[1].stage_i/x_out[5]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[13]} .original_name {{core/STAGE[1].stage_i/x_out[13]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[13]} .single_bit_orig_name {core/STAGE[1].stage_i/x_out[13]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[13]/Q} .original_name {core/STAGE[1].stage_i/x_out[13]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[11]} .original_name {{core/STAGE[1].stage_i/x_out[11]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[11]} .single_bit_orig_name {core/STAGE[1].stage_i/x_out[11]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[11]/Q} .original_name {core/STAGE[1].stage_i/x_out[11]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[7]} .original_name {{core/STAGE[1].stage_i/x_out[7]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[7]} .single_bit_orig_name {core/STAGE[1].stage_i/x_out[7]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[7]/Q} .original_name {core/STAGE[1].stage_i/x_out[7]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[6]} .original_name {{core/STAGE[1].stage_i/x_out[6]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[6]} .single_bit_orig_name {core/STAGE[1].stage_i/x_out[6]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[6]/Q} .original_name {core/STAGE[1].stage_i/x_out[6]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[10]} .original_name {{core/STAGE[1].stage_i/x_out[10]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[10]} .single_bit_orig_name {core/STAGE[1].stage_i/x_out[10]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[10]/Q} .original_name {core/STAGE[1].stage_i/x_out[10]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[14]} .original_name {{core/STAGE[1].stage_i/x_out[14]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[14]} .single_bit_orig_name {core/STAGE[1].stage_i/x_out[14]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[14]/Q} .original_name {core/STAGE[1].stage_i/x_out[14]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[2]} .original_name {{core/STAGE[1].stage_i/x_out[2]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[2]} .single_bit_orig_name {core/STAGE[1].stage_i/x_out[2]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[2]/Q} .original_name {core/STAGE[1].stage_i/x_out[2]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[12]} .original_name {{core/STAGE[1].stage_i/x_out[12]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[12]} .single_bit_orig_name {core/STAGE[1].stage_i/x_out[12]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[12]/Q} .original_name {core/STAGE[1].stage_i/x_out[12]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[9]} .original_name {{core/STAGE[1].stage_i/x_out[9]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[9]} .single_bit_orig_name {core/STAGE[1].stage_i/x_out[9]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[9]/Q} .original_name {core/STAGE[1].stage_i/x_out[9]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[3]} .original_name {{core/STAGE[1].stage_i/x_out[3]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[3]} .single_bit_orig_name {core/STAGE[1].stage_i/x_out[3]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[3]/Q} .original_name {core/STAGE[1].stage_i/x_out[3]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[4]} .original_name {{core/STAGE[1].stage_i/x_out[4]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[4]} .single_bit_orig_name {core/STAGE[1].stage_i/x_out[4]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[4]/Q} .original_name {core/STAGE[1].stage_i/x_out[4]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[8]} .original_name {{core/STAGE[1].stage_i/x_out[8]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[8]} .single_bit_orig_name {core/STAGE[1].stage_i/x_out[8]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[8]/Q} .original_name {core/STAGE[1].stage_i/x_out[8]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[1]} .original_name {{core/STAGE[1].stage_i/x_out[1]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[1]} .single_bit_orig_name {core/STAGE[1].stage_i/x_out[1]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[1]/Q} .original_name {core/STAGE[1].stage_i/x_out[1]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[0]} .original_name {{core/STAGE[1].stage_i/x_out[0]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[0]} .single_bit_orig_name {core/STAGE[1].stage_i/x_out[0]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[1].stage_i/x_out_reg[0]/Q} .original_name {core/STAGE[1].stage_i/x_out[0]/q}
set_db -quiet module:rope_csd_pair/csd_ud_stage_WIDTH15_SHIFT14_SHIFT25 .hdl_user_name csd_ud_stage
set_db -quiet module:rope_csd_pair/csd_ud_stage_WIDTH15_SHIFT14_SHIFT25 .hdl_filelist {{default -v2001 {SYNTHESIS} {/home/redhatacademy19/Documents/Siddhant/RTL/csd_ud_stage.v} {$rtlDir} {}}}
set_db -quiet module:rope_csd_pair/csd_ud_stage_WIDTH15_SHIFT14_SHIFT25 .lp_clock_gating_max_flops inf
set_db -quiet module:rope_csd_pair/csd_ud_stage_WIDTH15_SHIFT14_SHIFT25 .arch_filename /home/redhatacademy19/Documents/Siddhant/RTL/csd_ud_stage.v
set_db -quiet module:rope_csd_pair/csd_ud_stage_WIDTH15_SHIFT14_SHIFT25 .entity_filename /home/redhatacademy19/Documents/Siddhant/RTL/csd_ud_stage.v
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[5]} .original_name {{core/STAGE[2].stage_i/y_out[5]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[5]} .single_bit_orig_name {core/STAGE[2].stage_i/y_out[5]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[5]/Q} .original_name {core/STAGE[2].stage_i/y_out[5]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[13]} .original_name {{core/STAGE[2].stage_i/y_out[13]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[13]} .single_bit_orig_name {core/STAGE[2].stage_i/y_out[13]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[13]/Q} .original_name {core/STAGE[2].stage_i/y_out[13]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[11]} .original_name {{core/STAGE[2].stage_i/y_out[11]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[11]} .single_bit_orig_name {core/STAGE[2].stage_i/y_out[11]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[11]/Q} .original_name {core/STAGE[2].stage_i/y_out[11]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[7]} .original_name {{core/STAGE[2].stage_i/y_out[7]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[7]} .single_bit_orig_name {core/STAGE[2].stage_i/y_out[7]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[7]/Q} .original_name {core/STAGE[2].stage_i/y_out[7]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[6]} .original_name {{core/STAGE[2].stage_i/y_out[6]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[6]} .single_bit_orig_name {core/STAGE[2].stage_i/y_out[6]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[6]/Q} .original_name {core/STAGE[2].stage_i/y_out[6]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[10]} .original_name {{core/STAGE[2].stage_i/y_out[10]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[10]} .single_bit_orig_name {core/STAGE[2].stage_i/y_out[10]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[10]/Q} .original_name {core/STAGE[2].stage_i/y_out[10]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[14]} .original_name {{core/STAGE[2].stage_i/y_out[14]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[14]} .single_bit_orig_name {core/STAGE[2].stage_i/y_out[14]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[14]/Q} .original_name {core/STAGE[2].stage_i/y_out[14]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[2]} .original_name {{core/STAGE[2].stage_i/y_out[2]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[2]} .single_bit_orig_name {core/STAGE[2].stage_i/y_out[2]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[2]/Q} .original_name {core/STAGE[2].stage_i/y_out[2]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[12]} .original_name {{core/STAGE[2].stage_i/y_out[12]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[12]} .single_bit_orig_name {core/STAGE[2].stage_i/y_out[12]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[12]/Q} .original_name {core/STAGE[2].stage_i/y_out[12]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[9]} .original_name {{core/STAGE[2].stage_i/y_out[9]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[9]} .single_bit_orig_name {core/STAGE[2].stage_i/y_out[9]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[9]/Q} .original_name {core/STAGE[2].stage_i/y_out[9]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[3]} .original_name {{core/STAGE[2].stage_i/y_out[3]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[3]} .single_bit_orig_name {core/STAGE[2].stage_i/y_out[3]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[3]/Q} .original_name {core/STAGE[2].stage_i/y_out[3]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[4]} .original_name {{core/STAGE[2].stage_i/y_out[4]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[4]} .single_bit_orig_name {core/STAGE[2].stage_i/y_out[4]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[4]/Q} .original_name {core/STAGE[2].stage_i/y_out[4]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[8]} .original_name {{core/STAGE[2].stage_i/y_out[8]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[8]} .single_bit_orig_name {core/STAGE[2].stage_i/y_out[8]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[8]/Q} .original_name {core/STAGE[2].stage_i/y_out[8]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[1]} .original_name {{core/STAGE[2].stage_i/y_out[1]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[1]} .single_bit_orig_name {core/STAGE[2].stage_i/y_out[1]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[1]/Q} .original_name {core/STAGE[2].stage_i/y_out[1]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[0]} .original_name {{core/STAGE[2].stage_i/y_out[0]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[0]} .single_bit_orig_name {core/STAGE[2].stage_i/y_out[0]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[2].stage_i/y_out_reg[0]/Q} .original_name {core/STAGE[2].stage_i/y_out[0]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[5]} .original_name {{core/STAGE[2].stage_i/x_out[5]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[5]} .single_bit_orig_name {core/STAGE[2].stage_i/x_out[5]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[5]/Q} .original_name {core/STAGE[2].stage_i/x_out[5]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[13]} .original_name {{core/STAGE[2].stage_i/x_out[13]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[13]} .single_bit_orig_name {core/STAGE[2].stage_i/x_out[13]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[13]/Q} .original_name {core/STAGE[2].stage_i/x_out[13]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[11]} .original_name {{core/STAGE[2].stage_i/x_out[11]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[11]} .single_bit_orig_name {core/STAGE[2].stage_i/x_out[11]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[11]/Q} .original_name {core/STAGE[2].stage_i/x_out[11]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[7]} .original_name {{core/STAGE[2].stage_i/x_out[7]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[7]} .single_bit_orig_name {core/STAGE[2].stage_i/x_out[7]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[7]/Q} .original_name {core/STAGE[2].stage_i/x_out[7]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[6]} .original_name {{core/STAGE[2].stage_i/x_out[6]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[6]} .single_bit_orig_name {core/STAGE[2].stage_i/x_out[6]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[6]/Q} .original_name {core/STAGE[2].stage_i/x_out[6]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[10]} .original_name {{core/STAGE[2].stage_i/x_out[10]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[10]} .single_bit_orig_name {core/STAGE[2].stage_i/x_out[10]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[10]/Q} .original_name {core/STAGE[2].stage_i/x_out[10]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[14]} .original_name {{core/STAGE[2].stage_i/x_out[14]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[14]} .single_bit_orig_name {core/STAGE[2].stage_i/x_out[14]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[14]/Q} .original_name {core/STAGE[2].stage_i/x_out[14]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[2]} .original_name {{core/STAGE[2].stage_i/x_out[2]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[2]} .single_bit_orig_name {core/STAGE[2].stage_i/x_out[2]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[2]/Q} .original_name {core/STAGE[2].stage_i/x_out[2]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[12]} .original_name {{core/STAGE[2].stage_i/x_out[12]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[12]} .single_bit_orig_name {core/STAGE[2].stage_i/x_out[12]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[12]/Q} .original_name {core/STAGE[2].stage_i/x_out[12]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[9]} .original_name {{core/STAGE[2].stage_i/x_out[9]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[9]} .single_bit_orig_name {core/STAGE[2].stage_i/x_out[9]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[9]/Q} .original_name {core/STAGE[2].stage_i/x_out[9]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[3]} .original_name {{core/STAGE[2].stage_i/x_out[3]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[3]} .single_bit_orig_name {core/STAGE[2].stage_i/x_out[3]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[3]/Q} .original_name {core/STAGE[2].stage_i/x_out[3]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[4]} .original_name {{core/STAGE[2].stage_i/x_out[4]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[4]} .single_bit_orig_name {core/STAGE[2].stage_i/x_out[4]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[4]/Q} .original_name {core/STAGE[2].stage_i/x_out[4]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[8]} .original_name {{core/STAGE[2].stage_i/x_out[8]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[8]} .single_bit_orig_name {core/STAGE[2].stage_i/x_out[8]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[8]/Q} .original_name {core/STAGE[2].stage_i/x_out[8]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[1]} .original_name {{core/STAGE[2].stage_i/x_out[1]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[1]} .single_bit_orig_name {core/STAGE[2].stage_i/x_out[1]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[1]/Q} .original_name {core/STAGE[2].stage_i/x_out[1]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[0]} .original_name {{core/STAGE[2].stage_i/x_out[0]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[0]} .single_bit_orig_name {core/STAGE[2].stage_i/x_out[0]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[2].stage_i/x_out_reg[0]/Q} .original_name {core/STAGE[2].stage_i/x_out[0]/q}
set_db -quiet module:rope_csd_pair/csd_ud_stage_WIDTH15_SHIFT16_SHIFT27 .hdl_user_name csd_ud_stage
set_db -quiet module:rope_csd_pair/csd_ud_stage_WIDTH15_SHIFT16_SHIFT27 .hdl_filelist {{default -v2001 {SYNTHESIS} {/home/redhatacademy19/Documents/Siddhant/RTL/csd_ud_stage.v} {$rtlDir} {}}}
set_db -quiet module:rope_csd_pair/csd_ud_stage_WIDTH15_SHIFT16_SHIFT27 .lp_clock_gating_max_flops inf
set_db -quiet module:rope_csd_pair/csd_ud_stage_WIDTH15_SHIFT16_SHIFT27 .arch_filename /home/redhatacademy19/Documents/Siddhant/RTL/csd_ud_stage.v
set_db -quiet module:rope_csd_pair/csd_ud_stage_WIDTH15_SHIFT16_SHIFT27 .entity_filename /home/redhatacademy19/Documents/Siddhant/RTL/csd_ud_stage.v
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[5]} .original_name {{core/STAGE[3].stage_i/y_out[5]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[5]} .single_bit_orig_name {core/STAGE[3].stage_i/y_out[5]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[5]/Q} .original_name {core/STAGE[3].stage_i/y_out[5]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[13]} .original_name {{core/STAGE[3].stage_i/y_out[13]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[13]} .single_bit_orig_name {core/STAGE[3].stage_i/y_out[13]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[13]/Q} .original_name {core/STAGE[3].stage_i/y_out[13]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[11]} .original_name {{core/STAGE[3].stage_i/y_out[11]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[11]} .single_bit_orig_name {core/STAGE[3].stage_i/y_out[11]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[11]/Q} .original_name {core/STAGE[3].stage_i/y_out[11]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[7]} .original_name {{core/STAGE[3].stage_i/y_out[7]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[7]} .single_bit_orig_name {core/STAGE[3].stage_i/y_out[7]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[7]/Q} .original_name {core/STAGE[3].stage_i/y_out[7]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[6]} .original_name {{core/STAGE[3].stage_i/y_out[6]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[6]} .single_bit_orig_name {core/STAGE[3].stage_i/y_out[6]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[6]/Q} .original_name {core/STAGE[3].stage_i/y_out[6]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[10]} .original_name {{core/STAGE[3].stage_i/y_out[10]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[10]} .single_bit_orig_name {core/STAGE[3].stage_i/y_out[10]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[10]/Q} .original_name {core/STAGE[3].stage_i/y_out[10]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[14]} .original_name {{core/STAGE[3].stage_i/y_out[14]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[14]} .single_bit_orig_name {core/STAGE[3].stage_i/y_out[14]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[14]/Q} .original_name {core/STAGE[3].stage_i/y_out[14]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[2]} .original_name {{core/STAGE[3].stage_i/y_out[2]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[2]} .single_bit_orig_name {core/STAGE[3].stage_i/y_out[2]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[2]/Q} .original_name {core/STAGE[3].stage_i/y_out[2]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[12]} .original_name {{core/STAGE[3].stage_i/y_out[12]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[12]} .single_bit_orig_name {core/STAGE[3].stage_i/y_out[12]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[12]/Q} .original_name {core/STAGE[3].stage_i/y_out[12]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[9]} .original_name {{core/STAGE[3].stage_i/y_out[9]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[9]} .single_bit_orig_name {core/STAGE[3].stage_i/y_out[9]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[9]/Q} .original_name {core/STAGE[3].stage_i/y_out[9]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[3]} .original_name {{core/STAGE[3].stage_i/y_out[3]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[3]} .single_bit_orig_name {core/STAGE[3].stage_i/y_out[3]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[3]/Q} .original_name {core/STAGE[3].stage_i/y_out[3]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[4]} .original_name {{core/STAGE[3].stage_i/y_out[4]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[4]} .single_bit_orig_name {core/STAGE[3].stage_i/y_out[4]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[4]/Q} .original_name {core/STAGE[3].stage_i/y_out[4]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[8]} .original_name {{core/STAGE[3].stage_i/y_out[8]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[8]} .single_bit_orig_name {core/STAGE[3].stage_i/y_out[8]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[8]/Q} .original_name {core/STAGE[3].stage_i/y_out[8]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[1]} .original_name {{core/STAGE[3].stage_i/y_out[1]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[1]} .single_bit_orig_name {core/STAGE[3].stage_i/y_out[1]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[1]/Q} .original_name {core/STAGE[3].stage_i/y_out[1]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[0]} .original_name {{core/STAGE[3].stage_i/y_out[0]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[0]} .single_bit_orig_name {core/STAGE[3].stage_i/y_out[0]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[3].stage_i/y_out_reg[0]/Q} .original_name {core/STAGE[3].stage_i/y_out[0]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[5]} .original_name {{core/STAGE[3].stage_i/x_out[5]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[5]} .single_bit_orig_name {core/STAGE[3].stage_i/x_out[5]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[5]/Q} .original_name {core/STAGE[3].stage_i/x_out[5]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[13]} .original_name {{core/STAGE[3].stage_i/x_out[13]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[13]} .single_bit_orig_name {core/STAGE[3].stage_i/x_out[13]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[13]/Q} .original_name {core/STAGE[3].stage_i/x_out[13]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[11]} .original_name {{core/STAGE[3].stage_i/x_out[11]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[11]} .single_bit_orig_name {core/STAGE[3].stage_i/x_out[11]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[11]/Q} .original_name {core/STAGE[3].stage_i/x_out[11]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[7]} .original_name {{core/STAGE[3].stage_i/x_out[7]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[7]} .single_bit_orig_name {core/STAGE[3].stage_i/x_out[7]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[7]/Q} .original_name {core/STAGE[3].stage_i/x_out[7]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[6]} .original_name {{core/STAGE[3].stage_i/x_out[6]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[6]} .single_bit_orig_name {core/STAGE[3].stage_i/x_out[6]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[6]/Q} .original_name {core/STAGE[3].stage_i/x_out[6]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[10]} .original_name {{core/STAGE[3].stage_i/x_out[10]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[10]} .single_bit_orig_name {core/STAGE[3].stage_i/x_out[10]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[10]/Q} .original_name {core/STAGE[3].stage_i/x_out[10]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[14]} .original_name {{core/STAGE[3].stage_i/x_out[14]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[14]} .single_bit_orig_name {core/STAGE[3].stage_i/x_out[14]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[14]/Q} .original_name {core/STAGE[3].stage_i/x_out[14]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[2]} .original_name {{core/STAGE[3].stage_i/x_out[2]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[2]} .single_bit_orig_name {core/STAGE[3].stage_i/x_out[2]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[2]/Q} .original_name {core/STAGE[3].stage_i/x_out[2]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[12]} .original_name {{core/STAGE[3].stage_i/x_out[12]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[12]} .single_bit_orig_name {core/STAGE[3].stage_i/x_out[12]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[12]/Q} .original_name {core/STAGE[3].stage_i/x_out[12]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[9]} .original_name {{core/STAGE[3].stage_i/x_out[9]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[9]} .single_bit_orig_name {core/STAGE[3].stage_i/x_out[9]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[9]/Q} .original_name {core/STAGE[3].stage_i/x_out[9]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[3]} .original_name {{core/STAGE[3].stage_i/x_out[3]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[3]} .single_bit_orig_name {core/STAGE[3].stage_i/x_out[3]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[3]/Q} .original_name {core/STAGE[3].stage_i/x_out[3]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[4]} .original_name {{core/STAGE[3].stage_i/x_out[4]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[4]} .single_bit_orig_name {core/STAGE[3].stage_i/x_out[4]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[4]/Q} .original_name {core/STAGE[3].stage_i/x_out[4]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[8]} .original_name {{core/STAGE[3].stage_i/x_out[8]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[8]} .single_bit_orig_name {core/STAGE[3].stage_i/x_out[8]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[8]/Q} .original_name {core/STAGE[3].stage_i/x_out[8]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[1]} .original_name {{core/STAGE[3].stage_i/x_out[1]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[1]} .single_bit_orig_name {core/STAGE[3].stage_i/x_out[1]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[1]/Q} .original_name {core/STAGE[3].stage_i/x_out[1]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[0]} .original_name {{core/STAGE[3].stage_i/x_out[0]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[0]} .single_bit_orig_name {core/STAGE[3].stage_i/x_out[0]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[3].stage_i/x_out_reg[0]/Q} .original_name {core/STAGE[3].stage_i/x_out[0]/q}
set_db -quiet module:rope_csd_pair/csd_ud_stage_WIDTH15_SHIFT18_SHIFT29 .hdl_user_name csd_ud_stage
set_db -quiet module:rope_csd_pair/csd_ud_stage_WIDTH15_SHIFT18_SHIFT29 .hdl_filelist {{default -v2001 {SYNTHESIS} {/home/redhatacademy19/Documents/Siddhant/RTL/csd_ud_stage.v} {$rtlDir} {}}}
set_db -quiet module:rope_csd_pair/csd_ud_stage_WIDTH15_SHIFT18_SHIFT29 .lp_clock_gating_max_flops inf
set_db -quiet module:rope_csd_pair/csd_ud_stage_WIDTH15_SHIFT18_SHIFT29 .arch_filename /home/redhatacademy19/Documents/Siddhant/RTL/csd_ud_stage.v
set_db -quiet module:rope_csd_pair/csd_ud_stage_WIDTH15_SHIFT18_SHIFT29 .entity_filename /home/redhatacademy19/Documents/Siddhant/RTL/csd_ud_stage.v
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[12]} .original_name {{core/STAGE[4].stage_i/y_out[12]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[12]} .single_bit_orig_name {core/STAGE[4].stage_i/y_out[12]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[12]/Q} .original_name {core/STAGE[4].stage_i/y_out[12]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[13]} .original_name {{core/STAGE[4].stage_i/x_out[13]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[13]} .single_bit_orig_name {core/STAGE[4].stage_i/x_out[13]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[13]/Q} .original_name {core/STAGE[4].stage_i/x_out[13]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[11]} .original_name {{core/STAGE[4].stage_i/x_out[11]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[11]} .single_bit_orig_name {core/STAGE[4].stage_i/x_out[11]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[11]/Q} .original_name {core/STAGE[4].stage_i/x_out[11]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[7]} .original_name {{core/STAGE[4].stage_i/x_out[7]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[7]} .single_bit_orig_name {core/STAGE[4].stage_i/x_out[7]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[7]/Q} .original_name {core/STAGE[4].stage_i/x_out[7]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[14]} .original_name {{core/STAGE[4].stage_i/y_out[14]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[14]} .single_bit_orig_name {core/STAGE[4].stage_i/y_out[14]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[14]/Q} .original_name {core/STAGE[4].stage_i/y_out[14]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[13]} .original_name {{core/STAGE[4].stage_i/y_out[13]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[13]} .single_bit_orig_name {core/STAGE[4].stage_i/y_out[13]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[13]/Q} .original_name {core/STAGE[4].stage_i/y_out[13]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[6]} .original_name {{core/STAGE[4].stage_i/x_out[6]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[6]} .single_bit_orig_name {core/STAGE[4].stage_i/x_out[6]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[6]/Q} .original_name {core/STAGE[4].stage_i/x_out[6]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[14]} .original_name {{core/STAGE[4].stage_i/x_out[14]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[14]} .single_bit_orig_name {core/STAGE[4].stage_i/x_out[14]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[14]/Q} .original_name {core/STAGE[4].stage_i/x_out[14]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[11]} .original_name {{core/STAGE[4].stage_i/y_out[11]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[11]} .single_bit_orig_name {core/STAGE[4].stage_i/y_out[11]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[11]/Q} .original_name {core/STAGE[4].stage_i/y_out[11]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[10]} .original_name {{core/STAGE[4].stage_i/x_out[10]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[10]} .single_bit_orig_name {core/STAGE[4].stage_i/x_out[10]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[10]/Q} .original_name {core/STAGE[4].stage_i/x_out[10]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[5]} .original_name {{core/STAGE[4].stage_i/x_out[5]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[5]} .single_bit_orig_name {core/STAGE[4].stage_i/x_out[5]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[5]/Q} .original_name {core/STAGE[4].stage_i/x_out[5]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[10]} .original_name {{core/STAGE[4].stage_i/y_out[10]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[10]} .single_bit_orig_name {core/STAGE[4].stage_i/y_out[10]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[10]/Q} .original_name {core/STAGE[4].stage_i/y_out[10]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[9]} .original_name {{core/STAGE[4].stage_i/y_out[9]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[9]} .single_bit_orig_name {core/STAGE[4].stage_i/y_out[9]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[9]/Q} .original_name {core/STAGE[4].stage_i/y_out[9]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[4]} .original_name {{core/STAGE[4].stage_i/x_out[4]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[4]} .single_bit_orig_name {core/STAGE[4].stage_i/x_out[4]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[4]/Q} .original_name {core/STAGE[4].stage_i/x_out[4]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[8]} .original_name {{core/STAGE[4].stage_i/y_out[8]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[8]} .single_bit_orig_name {core/STAGE[4].stage_i/y_out[8]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[8]/Q} .original_name {core/STAGE[4].stage_i/y_out[8]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[4]} .original_name {{core/STAGE[4].stage_i/y_out[4]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[4]} .single_bit_orig_name {core/STAGE[4].stage_i/y_out[4]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[4]/Q} .original_name {core/STAGE[4].stage_i/y_out[4]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[12]} .original_name {{core/STAGE[4].stage_i/x_out[12]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[12]} .single_bit_orig_name {core/STAGE[4].stage_i/x_out[12]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[12]/Q} .original_name {core/STAGE[4].stage_i/x_out[12]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[9]} .original_name {{core/STAGE[4].stage_i/x_out[9]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[9]} .single_bit_orig_name {core/STAGE[4].stage_i/x_out[9]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[9]/Q} .original_name {core/STAGE[4].stage_i/x_out[9]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[3]} .original_name {{core/STAGE[4].stage_i/x_out[3]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[3]} .single_bit_orig_name {core/STAGE[4].stage_i/x_out[3]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[3]/Q} .original_name {core/STAGE[4].stage_i/x_out[3]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[6]} .original_name {{core/STAGE[4].stage_i/y_out[6]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[6]} .single_bit_orig_name {core/STAGE[4].stage_i/y_out[6]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[6]/Q} .original_name {core/STAGE[4].stage_i/y_out[6]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[5]} .original_name {{core/STAGE[4].stage_i/y_out[5]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[5]} .single_bit_orig_name {core/STAGE[4].stage_i/y_out[5]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[5]/Q} .original_name {core/STAGE[4].stage_i/y_out[5]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[2]} .original_name {{core/STAGE[4].stage_i/x_out[2]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[2]} .single_bit_orig_name {core/STAGE[4].stage_i/x_out[2]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[2]/Q} .original_name {core/STAGE[4].stage_i/x_out[2]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[7]} .original_name {{core/STAGE[4].stage_i/y_out[7]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[7]} .single_bit_orig_name {core/STAGE[4].stage_i/y_out[7]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[7]/Q} .original_name {core/STAGE[4].stage_i/y_out[7]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[3]} .original_name {{core/STAGE[4].stage_i/y_out[3]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[3]} .single_bit_orig_name {core/STAGE[4].stage_i/y_out[3]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[3]/Q} .original_name {core/STAGE[4].stage_i/y_out[3]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[8]} .original_name {{core/STAGE[4].stage_i/x_out[8]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[8]} .single_bit_orig_name {core/STAGE[4].stage_i/x_out[8]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[8]/Q} .original_name {core/STAGE[4].stage_i/x_out[8]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[1]} .original_name {{core/STAGE[4].stage_i/x_out[1]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[1]} .single_bit_orig_name {core/STAGE[4].stage_i/x_out[1]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[1]/Q} .original_name {core/STAGE[4].stage_i/x_out[1]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[2]} .original_name {{core/STAGE[4].stage_i/y_out[2]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[2]} .single_bit_orig_name {core/STAGE[4].stage_i/y_out[2]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[2]/Q} .original_name {core/STAGE[4].stage_i/y_out[2]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[1]} .original_name {{core/STAGE[4].stage_i/y_out[1]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[1]} .single_bit_orig_name {core/STAGE[4].stage_i/y_out[1]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[1]/Q} .original_name {core/STAGE[4].stage_i/y_out[1]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[0]} .original_name {{core/STAGE[4].stage_i/x_out[0]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[0]} .single_bit_orig_name {core/STAGE[4].stage_i/x_out[0]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[4].stage_i/x_out_reg[0]/Q} .original_name {core/STAGE[4].stage_i/x_out[0]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[0]} .original_name {{core/STAGE[4].stage_i/y_out[0]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[0]} .single_bit_orig_name {core/STAGE[4].stage_i/y_out[0]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[4].stage_i/y_out_reg[0]/Q} .original_name {core/STAGE[4].stage_i/y_out[0]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[5]} .original_name {{core/STAGE[0].stage_i/y_out[5]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[5]} .single_bit_orig_name {core/STAGE[0].stage_i/y_out[5]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[5]/Q} .original_name {core/STAGE[0].stage_i/y_out[5]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[13]} .original_name {{core/STAGE[0].stage_i/y_out[13]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[13]} .single_bit_orig_name {core/STAGE[0].stage_i/y_out[13]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[13]/Q} .original_name {core/STAGE[0].stage_i/y_out[13]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[11]} .original_name {{core/STAGE[0].stage_i/y_out[11]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[11]} .single_bit_orig_name {core/STAGE[0].stage_i/y_out[11]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[11]/Q} .original_name {core/STAGE[0].stage_i/y_out[11]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[7]} .original_name {{core/STAGE[0].stage_i/y_out[7]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[7]} .single_bit_orig_name {core/STAGE[0].stage_i/y_out[7]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[7]/Q} .original_name {core/STAGE[0].stage_i/y_out[7]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[6]} .original_name {{core/STAGE[0].stage_i/y_out[6]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[6]} .single_bit_orig_name {core/STAGE[0].stage_i/y_out[6]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[6]/Q} .original_name {core/STAGE[0].stage_i/y_out[6]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[10]} .original_name {{core/STAGE[0].stage_i/y_out[10]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[10]} .single_bit_orig_name {core/STAGE[0].stage_i/y_out[10]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[10]/Q} .original_name {core/STAGE[0].stage_i/y_out[10]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[14]} .original_name {{core/STAGE[0].stage_i/y_out[14]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[14]} .single_bit_orig_name {core/STAGE[0].stage_i/y_out[14]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[14]/Q} .original_name {core/STAGE[0].stage_i/y_out[14]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[2]} .original_name {{core/STAGE[0].stage_i/y_out[2]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[2]} .single_bit_orig_name {core/STAGE[0].stage_i/y_out[2]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[2]/Q} .original_name {core/STAGE[0].stage_i/y_out[2]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[12]} .original_name {{core/STAGE[0].stage_i/y_out[12]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[12]} .single_bit_orig_name {core/STAGE[0].stage_i/y_out[12]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[12]/Q} .original_name {core/STAGE[0].stage_i/y_out[12]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[9]} .original_name {{core/STAGE[0].stage_i/y_out[9]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[9]} .single_bit_orig_name {core/STAGE[0].stage_i/y_out[9]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[9]/Q} .original_name {core/STAGE[0].stage_i/y_out[9]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[3]} .original_name {{core/STAGE[0].stage_i/y_out[3]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[3]} .single_bit_orig_name {core/STAGE[0].stage_i/y_out[3]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[3]/Q} .original_name {core/STAGE[0].stage_i/y_out[3]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[4]} .original_name {{core/STAGE[0].stage_i/y_out[4]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[4]} .single_bit_orig_name {core/STAGE[0].stage_i/y_out[4]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[4]/Q} .original_name {core/STAGE[0].stage_i/y_out[4]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[8]} .original_name {{core/STAGE[0].stage_i/y_out[8]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[8]} .single_bit_orig_name {core/STAGE[0].stage_i/y_out[8]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[8]/Q} .original_name {core/STAGE[0].stage_i/y_out[8]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[1]} .original_name {{core/STAGE[0].stage_i/y_out[1]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[1]} .single_bit_orig_name {core/STAGE[0].stage_i/y_out[1]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[1]/Q} .original_name {core/STAGE[0].stage_i/y_out[1]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[0]} .original_name {{core/STAGE[0].stage_i/y_out[0]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[0]} .single_bit_orig_name {core/STAGE[0].stage_i/y_out[0]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[0].stage_i_y_out_reg[0]/Q} .original_name {core/STAGE[0].stage_i/y_out[0]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][0][1]} .original_name {{core/delta_pipe[0][0][1]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][0][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][0][1]} .single_bit_orig_name {core/delta_pipe[0][0][1]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][0][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[0][0][1]/Q} .original_name {core/delta_pipe[0][0][1]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][0][0]} .original_name {{core/delta_pipe[0][0][0]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][0][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][0][0]} .single_bit_orig_name {core/delta_pipe[0][0][0]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][0][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[0][0][0]/Q} .original_name {core/delta_pipe[0][0][0]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][1][0]} .original_name {{core/delta_pipe[0][1][0]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][1][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][1][0]} .single_bit_orig_name {core/delta_pipe[0][1][0]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][1][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[0][1][0]/Q} .original_name {core/delta_pipe[0][1][0]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][1][1]} .original_name {{core/delta_pipe[0][1][1]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][1][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][1][1]} .single_bit_orig_name {core/delta_pipe[0][1][1]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][1][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[0][1][1]/Q} .original_name {core/delta_pipe[0][1][1]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][1][2]} .original_name {{core/delta_pipe[0][1][2]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][1][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][1][2]} .single_bit_orig_name {core/delta_pipe[0][1][2]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][1][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[0][1][2]/Q} .original_name {core/delta_pipe[0][1][2]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][2][0]} .original_name {{core/delta_pipe[0][2][0]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][2][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][2][0]} .single_bit_orig_name {core/delta_pipe[0][2][0]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][2][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[0][2][0]/Q} .original_name {core/delta_pipe[0][2][0]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][2][1]} .original_name {{core/delta_pipe[0][2][1]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][2][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][2][1]} .single_bit_orig_name {core/delta_pipe[0][2][1]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][2][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[0][2][1]/Q} .original_name {core/delta_pipe[0][2][1]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][2][2]} .original_name {{core/delta_pipe[0][2][2]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][2][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][2][2]} .single_bit_orig_name {core/delta_pipe[0][2][2]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][2][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[0][2][2]/Q} .original_name {core/delta_pipe[0][2][2]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][3][0]} .original_name {{core/delta_pipe[0][3][0]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][3][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][3][0]} .single_bit_orig_name {core/delta_pipe[0][3][0]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][3][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[0][3][0]/Q} .original_name {core/delta_pipe[0][3][0]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][3][1]} .original_name {{core/delta_pipe[0][3][1]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][3][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][3][1]} .single_bit_orig_name {core/delta_pipe[0][3][1]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][3][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[0][3][1]/Q} .original_name {core/delta_pipe[0][3][1]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][3][2]} .original_name {{core/delta_pipe[0][3][2]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][3][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][3][2]} .single_bit_orig_name {core/delta_pipe[0][3][2]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][3][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[0][3][2]/Q} .original_name {core/delta_pipe[0][3][2]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][4][0]} .original_name {{core/delta_pipe[0][4][0]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][4][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][4][0]} .single_bit_orig_name {core/delta_pipe[0][4][0]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][4][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[0][4][0]/Q} .original_name {core/delta_pipe[0][4][0]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][4][1]} .original_name {{core/delta_pipe[0][4][1]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][4][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][4][1]} .single_bit_orig_name {core/delta_pipe[0][4][1]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][4][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[0][4][1]/Q} .original_name {core/delta_pipe[0][4][1]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][4][2]} .original_name {{core/delta_pipe[0][4][2]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][4][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][4][2]} .single_bit_orig_name {core/delta_pipe[0][4][2]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[0][4][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[0][4][2]/Q} .original_name {core/delta_pipe[0][4][2]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][1][0]} .original_name {{core/delta_pipe[1][1][0]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][1][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][1][0]} .single_bit_orig_name {core/delta_pipe[1][1][0]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][1][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[1][1][0]/Q} .original_name {core/delta_pipe[1][1][0]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][1][1]} .original_name {{core/delta_pipe[1][1][1]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][1][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][1][1]} .single_bit_orig_name {core/delta_pipe[1][1][1]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][1][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[1][1][1]/Q} .original_name {core/delta_pipe[1][1][1]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][1][2]} .original_name {{core/delta_pipe[1][1][2]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][1][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][1][2]} .single_bit_orig_name {core/delta_pipe[1][1][2]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][1][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[1][1][2]/Q} .original_name {core/delta_pipe[1][1][2]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][2][0]} .original_name {{core/delta_pipe[1][2][0]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][2][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][2][0]} .single_bit_orig_name {core/delta_pipe[1][2][0]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][2][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[1][2][0]/Q} .original_name {core/delta_pipe[1][2][0]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][2][1]} .original_name {{core/delta_pipe[1][2][1]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][2][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][2][1]} .single_bit_orig_name {core/delta_pipe[1][2][1]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][2][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[1][2][1]/Q} .original_name {core/delta_pipe[1][2][1]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][2][2]} .original_name {{core/delta_pipe[1][2][2]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][2][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][2][2]} .single_bit_orig_name {core/delta_pipe[1][2][2]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][2][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[1][2][2]/Q} .original_name {core/delta_pipe[1][2][2]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][3][0]} .original_name {{core/delta_pipe[1][3][0]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][3][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][3][0]} .single_bit_orig_name {core/delta_pipe[1][3][0]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][3][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[1][3][0]/Q} .original_name {core/delta_pipe[1][3][0]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][3][1]} .original_name {{core/delta_pipe[1][3][1]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][3][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][3][1]} .single_bit_orig_name {core/delta_pipe[1][3][1]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][3][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[1][3][1]/Q} .original_name {core/delta_pipe[1][3][1]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][3][2]} .original_name {{core/delta_pipe[1][3][2]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][3][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][3][2]} .single_bit_orig_name {core/delta_pipe[1][3][2]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][3][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[1][3][2]/Q} .original_name {core/delta_pipe[1][3][2]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][4][0]} .original_name {{core/delta_pipe[1][4][0]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][4][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][4][0]} .single_bit_orig_name {core/delta_pipe[1][4][0]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][4][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[1][4][0]/Q} .original_name {core/delta_pipe[1][4][0]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][4][1]} .original_name {{core/delta_pipe[1][4][1]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][4][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][4][1]} .single_bit_orig_name {core/delta_pipe[1][4][1]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][4][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[1][4][1]/Q} .original_name {core/delta_pipe[1][4][1]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][4][2]} .original_name {{core/delta_pipe[1][4][2]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][4][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][4][2]} .single_bit_orig_name {core/delta_pipe[1][4][2]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[1][4][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[1][4][2]/Q} .original_name {core/delta_pipe[1][4][2]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][2][0]} .original_name {{core/delta_pipe[2][2][0]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][2][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][2][0]} .single_bit_orig_name {core/delta_pipe[2][2][0]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][2][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[2][2][0]/Q} .original_name {core/delta_pipe[2][2][0]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][2][1]} .original_name {{core/delta_pipe[2][2][1]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][2][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][2][1]} .single_bit_orig_name {core/delta_pipe[2][2][1]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][2][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[2][2][1]/Q} .original_name {core/delta_pipe[2][2][1]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][2][2]} .original_name {{core/delta_pipe[2][2][2]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][2][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][2][2]} .single_bit_orig_name {core/delta_pipe[2][2][2]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][2][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[2][2][2]/Q} .original_name {core/delta_pipe[2][2][2]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][3][0]} .original_name {{core/delta_pipe[2][3][0]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][3][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][3][0]} .single_bit_orig_name {core/delta_pipe[2][3][0]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][3][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[2][3][0]/Q} .original_name {core/delta_pipe[2][3][0]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][3][1]} .original_name {{core/delta_pipe[2][3][1]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][3][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][3][1]} .single_bit_orig_name {core/delta_pipe[2][3][1]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][3][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[2][3][1]/Q} .original_name {core/delta_pipe[2][3][1]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][3][2]} .original_name {{core/delta_pipe[2][3][2]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][3][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][3][2]} .single_bit_orig_name {core/delta_pipe[2][3][2]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][3][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[2][3][2]/Q} .original_name {core/delta_pipe[2][3][2]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][4][0]} .original_name {{core/delta_pipe[2][4][0]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][4][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][4][0]} .single_bit_orig_name {core/delta_pipe[2][4][0]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][4][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[2][4][0]/Q} .original_name {core/delta_pipe[2][4][0]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][4][1]} .original_name {{core/delta_pipe[2][4][1]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][4][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][4][1]} .single_bit_orig_name {core/delta_pipe[2][4][1]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][4][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[2][4][1]/Q} .original_name {core/delta_pipe[2][4][1]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][4][2]} .original_name {{core/delta_pipe[2][4][2]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][4][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][4][2]} .single_bit_orig_name {core/delta_pipe[2][4][2]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[2][4][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[2][4][2]/Q} .original_name {core/delta_pipe[2][4][2]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[3][3][0]} .original_name {{core/delta_pipe[3][3][0]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[3][3][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[3][3][0]} .single_bit_orig_name {core/delta_pipe[3][3][0]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[3][3][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[3][3][0]/Q} .original_name {core/delta_pipe[3][3][0]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[3][3][1]} .original_name {{core/delta_pipe[3][3][1]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[3][3][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[3][3][1]} .single_bit_orig_name {core/delta_pipe[3][3][1]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[3][3][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[3][3][1]/Q} .original_name {core/delta_pipe[3][3][1]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[3][3][2]} .original_name {{core/delta_pipe[3][3][2]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[3][3][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[3][3][2]} .single_bit_orig_name {core/delta_pipe[3][3][2]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[3][3][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[3][3][2]/Q} .original_name {core/delta_pipe[3][3][2]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[3][4][0]} .original_name {{core/delta_pipe[3][4][0]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[3][4][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[3][4][0]} .single_bit_orig_name {core/delta_pipe[3][4][0]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[3][4][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[3][4][0]/Q} .original_name {core/delta_pipe[3][4][0]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[3][4][1]} .original_name {{core/delta_pipe[3][4][1]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[3][4][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[3][4][1]} .single_bit_orig_name {core/delta_pipe[3][4][1]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[3][4][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[3][4][1]/Q} .original_name {core/delta_pipe[3][4][1]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[3][4][2]} .original_name {{core/delta_pipe[3][4][2]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[3][4][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[3][4][2]} .single_bit_orig_name {core/delta_pipe[3][4][2]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[3][4][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[3][4][2]/Q} .original_name {core/delta_pipe[3][4][2]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[4][4][0]} .original_name {{core/delta_pipe[4][4][0]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[4][4][0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[4][4][0]} .single_bit_orig_name {core/delta_pipe[4][4][0]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[4][4][0]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[4][4][0]/Q} .original_name {core/delta_pipe[4][4][0]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[4][4][1]} .original_name {{core/delta_pipe[4][4][1]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[4][4][1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[4][4][1]} .single_bit_orig_name {core/delta_pipe[4][4][1]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[4][4][1]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[4][4][1]/Q} .original_name {core/delta_pipe[4][4][1]/q}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[4][4][2]} .original_name {{core/delta_pipe[4][4][2]}}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[4][4][2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[4][4][2]} .single_bit_orig_name {core/delta_pipe[4][4][2]}
set_db -quiet {inst:rope_csd_pair/core_delta_pipe_reg[4][4][2]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_delta_pipe_reg[4][4][2]/Q} .original_name {core/delta_pipe[4][4][2]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[5]} .original_name {{core/STAGE[0].stage_i/x_out[5]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[5]} .single_bit_orig_name {core/STAGE[0].stage_i/x_out[5]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[5]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[5]/Q} .original_name {core/STAGE[0].stage_i/x_out[5]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[13]} .original_name {{core/STAGE[0].stage_i/x_out[13]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[13]} .single_bit_orig_name {core/STAGE[0].stage_i/x_out[13]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[13]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[13]/Q} .original_name {core/STAGE[0].stage_i/x_out[13]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[11]} .original_name {{core/STAGE[0].stage_i/x_out[11]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[11]} .single_bit_orig_name {core/STAGE[0].stage_i/x_out[11]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[11]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[11]/Q} .original_name {core/STAGE[0].stage_i/x_out[11]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[7]} .original_name {{core/STAGE[0].stage_i/x_out[7]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[7]} .single_bit_orig_name {core/STAGE[0].stage_i/x_out[7]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[7]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[7]/Q} .original_name {core/STAGE[0].stage_i/x_out[7]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[6]} .original_name {{core/STAGE[0].stage_i/x_out[6]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[6]} .single_bit_orig_name {core/STAGE[0].stage_i/x_out[6]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[6]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[6]/Q} .original_name {core/STAGE[0].stage_i/x_out[6]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[10]} .original_name {{core/STAGE[0].stage_i/x_out[10]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[10]} .single_bit_orig_name {core/STAGE[0].stage_i/x_out[10]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[10]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[10]/Q} .original_name {core/STAGE[0].stage_i/x_out[10]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[14]} .original_name {{core/STAGE[0].stage_i/x_out[14]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[14]} .single_bit_orig_name {core/STAGE[0].stage_i/x_out[14]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[14]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[14]/Q} .original_name {core/STAGE[0].stage_i/x_out[14]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[2]} .original_name {{core/STAGE[0].stage_i/x_out[2]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[2]} .single_bit_orig_name {core/STAGE[0].stage_i/x_out[2]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[2]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[2]/Q} .original_name {core/STAGE[0].stage_i/x_out[2]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[12]} .original_name {{core/STAGE[0].stage_i/x_out[12]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[12]} .single_bit_orig_name {core/STAGE[0].stage_i/x_out[12]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[12]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[12]/Q} .original_name {core/STAGE[0].stage_i/x_out[12]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[9]} .original_name {{core/STAGE[0].stage_i/x_out[9]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[9]} .single_bit_orig_name {core/STAGE[0].stage_i/x_out[9]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[9]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[9]/Q} .original_name {core/STAGE[0].stage_i/x_out[9]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[3]} .original_name {{core/STAGE[0].stage_i/x_out[3]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[3]} .single_bit_orig_name {core/STAGE[0].stage_i/x_out[3]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[3]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[3]/Q} .original_name {core/STAGE[0].stage_i/x_out[3]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[4]} .original_name {{core/STAGE[0].stage_i/x_out[4]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[4]} .single_bit_orig_name {core/STAGE[0].stage_i/x_out[4]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[4]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[4]/Q} .original_name {core/STAGE[0].stage_i/x_out[4]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[8]} .original_name {{core/STAGE[0].stage_i/x_out[8]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[8]} .single_bit_orig_name {core/STAGE[0].stage_i/x_out[8]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[8]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[8]/Q} .original_name {core/STAGE[0].stage_i/x_out[8]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[1]} .original_name {{core/STAGE[0].stage_i/x_out[1]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[1]} .single_bit_orig_name {core/STAGE[0].stage_i/x_out[1]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[1]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[1]/Q} .original_name {core/STAGE[0].stage_i/x_out[1]/q}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[0]} .original_name {{core/STAGE[0].stage_i/x_out[0]}}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[0]} .single_bit_orig_name {core/STAGE[0].stage_i/x_out[0]}
set_db -quiet {inst:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[0]} .gint_phase_inversion false
set_db -quiet {pin:rope_csd_pair/core_STAGE[0].stage_i_x_out_reg[0]/Q} .original_name {core/STAGE[0].stage_i/x_out[0]/q}
# BEGIN PMBIST SECTION
# END PMBIST SECTION
# BEGIN PHYSICAL ANNOTATION SECTION
# END PHYSICAL ANNOTATION SECTION
set_db -quiet source_verbose true
#############################################################
#####   FLOW WRITE   ########################################
##
## Written by Genus(TM) Synthesis Solution version 21.10-p002_1
## flowkit v21.10-d047_1
## Written on 18:38:38 22-Apr 2026
#############################################################
#####   Flow Definitions   ##################################

#############################################################
#####   Step Definitions   ##################################


#############################################################
#####   Attribute Definitions   #############################

if {[is_attribute flow_edit_end_steps -obj_type root]} {set_db flow_edit_end_steps {}}
if {[is_attribute flow_edit_start_steps -obj_type root]} {set_db flow_edit_start_steps {}}
if {[is_attribute flow_footer_tcl -obj_type root]} {set_db flow_footer_tcl {}}
if {[is_attribute flow_header_tcl -obj_type root]} {set_db flow_header_tcl {}}
if {[is_attribute flow_metadata -obj_type root]} {set_db flow_metadata {}}
if {[is_attribute flow_setup_config -obj_type root]} {set_db flow_setup_config {HUDDLE {!!map {}}}}
if {[is_attribute flow_step_begin_tcl -obj_type root]} {set_db flow_step_begin_tcl {}}
if {[is_attribute flow_step_check_tcl -obj_type root]} {set_db flow_step_check_tcl {}}
if {[is_attribute flow_step_end_tcl -obj_type root]} {set_db flow_step_end_tcl {}}
if {[is_attribute flow_step_order -obj_type root]} {set_db flow_step_order {}}
if {[is_attribute flow_summary_tcl -obj_type root]} {set_db flow_summary_tcl {}}
if {[is_attribute flow_template_feature_definition -obj_type root]} {set_db flow_template_feature_definition {}}
if {[is_attribute flow_template_type -obj_type root]} {set_db flow_template_type {}}
if {[is_attribute flow_template_tools -obj_type root]} {set_db flow_template_tools {}}
if {[is_attribute flow_template_version -obj_type root]} {set_db flow_template_version {}}
if {[is_attribute flow_user_templates -obj_type root]} {set_db flow_user_templates {}}


#############################################################
#####   Flow History   ######################################

if {[is_attribute flow_user_templates -obj_type root]} {set_db flow_user_templates {}}
if {[is_attribute flow_plugin_steps -obj_type root]} {set_db flow_plugin_steps {}}
if {[is_attribute flow_template_type -obj_type root]} {set_db flow_template_type {}}
if {[is_attribute flow_template_tools -obj_type root]} {set_db flow_template_tools {}}
if {[is_attribute flow_template_version -obj_type root]} {set_db flow_template_version {}}
if {[is_attribute flow_template_feature_definition -obj_type root]} {set_db flow_template_feature_definition {}}
if {[is_attribute flow_remark -obj_type root]} {set_db flow_remark {}}
if {[is_attribute flow_features -obj_type root]} {set_db flow_features {}}
if {[is_attribute flow_feature_values -obj_type root]} {set_db flow_feature_values {}}
if {[is_attribute flow_write_db_args -obj_type root]} {set_db flow_write_db_args {}}
if {[is_attribute flow_write_db_sdc -obj_type root]} {set_db flow_write_db_sdc true}
if {[is_attribute flow_write_db_common -obj_type root]} {set_db flow_write_db_common false}
if {[is_attribute flow_post_db_overwrite -obj_type root]} {set_db flow_post_db_overwrite {}}
if {[is_attribute flow_step_order -obj_type root]} {set_db flow_step_order {}}
if {[is_attribute flow_step_begin_tcl -obj_type root]} {set_db flow_step_begin_tcl {}}
if {[is_attribute flow_step_end_tcl -obj_type root]} {set_db flow_step_end_tcl {}}
if {[is_attribute flow_step_last -obj_type root]} {set_db flow_step_last {}}
if {[is_attribute flow_step_current -obj_type root]} {set_db flow_step_current {}}
if {[is_attribute flow_step_canonical_current -obj_type root]} {set_db flow_step_canonical_current {}}
if {[is_attribute flow_step_next -obj_type root]} {set_db flow_step_next {}}
if {[is_attribute flow_working_directory -obj_type root]} {set_db flow_working_directory .}
if {[is_attribute flow_branch -obj_type root]} {set_db flow_branch {}}
if {[is_attribute flow_caller_data -obj_type root]} {set_db flow_caller_data {}}
if {[is_attribute flow_metrics_snapshot_uuid -obj_type root]} {set_db flow_metrics_snapshot_uuid c1c498df-ffbf-4699-99e8-1a064b9e6b9f}
if {[is_attribute flow_starting_db -obj_type root]} {set_db flow_starting_db {}}
if {[is_attribute flow_db_directory -obj_type root]} {set_db flow_db_directory dbs}
if {[is_attribute flow_report_directory -obj_type root]} {set_db flow_report_directory reports}
if {[is_attribute flow_log_directory -obj_type root]} {set_db flow_log_directory logs}
if {[is_attribute flow_mail_to -obj_type root]} {set_db flow_mail_to {}}
if {[is_attribute flow_exit_when_done -obj_type root]} {set_db flow_exit_when_done false}
if {[is_attribute flow_mail_on_error -obj_type root]} {set_db flow_mail_on_error false}
if {[is_attribute flow_summary_tcl -obj_type root]} {set_db flow_summary_tcl {}}
if {[is_attribute flow_history -obj_type root]} {set_db flow_history {}}
if {[is_attribute flow_step_last_status -obj_type root]} {set_db flow_step_last_status not_run}
if {[is_attribute flow_step_last_msg -obj_type root]} {set_db flow_step_last_msg {}}
if {[is_attribute flow_run_tag -obj_type root]} {set_db flow_run_tag {}}
if {[is_attribute flow_current_cache -obj_type root]} {set_db flow_current_cache {}}
if {[is_attribute flow_step_order_cache -obj_type root]} {set_db flow_step_order_cache {}}
if {[is_attribute flow_step_results_cache -obj_type root]} {set_db flow_step_results_cache {}}
if {[is_attribute flow_metadata -obj_type root]} {set_db flow_metadata {}}
if {[is_attribute flow_execute_in_global -obj_type root]} {set_db flow_execute_in_global true}
if {[is_attribute flow_overwrite_db -obj_type root]} {set_db flow_overwrite_db false}
if {[is_attribute flow_print_run_information -obj_type root]} {set_db flow_print_run_information false}
if {[is_attribute flow_verbose -obj_type root]} {set_db flow_verbose true}
if {[is_attribute flow_print_run_information_full -obj_type root]} {set_db flow_print_run_information_full false}
if {[is_attribute flow_header_tcl -obj_type root]} {set_db flow_header_tcl {}}
if {[is_attribute flow_footer_tcl -obj_type root]} {set_db flow_footer_tcl {}}
if {[is_attribute flow_init_header_tcl -obj_type root]} {set_db flow_init_header_tcl {}}
if {[is_attribute flow_init_footer_tcl -obj_type root]} {set_db flow_init_footer_tcl {}}
if {[is_attribute flow_edit_start_steps -obj_type root]} {set_db flow_edit_start_steps {}}
if {[is_attribute flow_edit_end_steps -obj_type root]} {set_db flow_edit_end_steps {}}
if {[is_attribute flow_step_last_number -obj_type root]} {set_db flow_step_last_number 0}
if {[is_attribute flow_autoload_applets -obj_type root]} {set_db flow_autoload_applets false}
if {[is_attribute flow_autoload_dir -obj_type root]} {set_db flow_autoload_dir error}
if {[is_attribute flow_skip_auto_db_save -obj_type root]} {set_db flow_skip_auto_db_save true}
if {[is_attribute flow_skip_auto_generate_metrics -obj_type root]} {set_db flow_skip_auto_generate_metrics false}
if {[is_attribute flow_top -obj_type root]} {set_db flow_top {}}
if {[is_attribute flow_hier_path -obj_type root]} {set_db flow_hier_path {}}
if {[is_attribute flow_schedule -obj_type root]} {set_db flow_schedule {}}
if {[is_attribute flow_step_check_tcl -obj_type root]} {set_db flow_step_check_tcl {}}
if {[is_attribute flow_script -obj_type root]} {set_db flow_script {}}
if {[is_attribute flow_yaml_script -obj_type root]} {set_db flow_yaml_script {}}
if {[is_attribute flow_cla_enabled_features -obj_type root]} {set_db flow_cla_enabled_features {}}
if {[is_attribute flow_cla_inject_tcl -obj_type root]} {set_db flow_cla_inject_tcl {}}
if {[is_attribute flow_error_message -obj_type root]} {set_db flow_error_message {}}
if {[is_attribute flow_error_errorinfo -obj_type root]} {set_db flow_error_errorinfo {}}
if {[is_attribute flow_reset_time_after_flow_init -obj_type root]} {set_db flow_reset_time_after_flow_init false}
if {[is_attribute flow_error_write_db -obj_type root]} {set_db flow_error_write_db true}
if {[is_attribute flow_advanced_metric_isolation -obj_type root]} {set_db flow_advanced_metric_isolation flow}
if {[is_attribute flow_yaml_root -obj_type root]} {set_db flow_yaml_root {}}
if {[is_attribute flow_yaml_root_dir -obj_type root]} {set_db flow_yaml_root_dir {}}
if {[is_attribute flow_setup_config -obj_type root]} {set_db flow_setup_config {HUDDLE {!!map {}}}}
if {[is_attribute flow_yamllint_exec -obj_type root]} {set_db flow_yamllint_exec yamllint}

#############################################################
#####   User Defined Attributes   ###########################

